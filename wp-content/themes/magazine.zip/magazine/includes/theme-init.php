<?php 

/* General file for include */
require_once dirname( __FILE__ ) . '/theme-functions.php';	// semua fungsi apa az ada di sini 
require_once dirname( __FILE__ ) . '/theme-ads-functions.php';	// Ads functions 
require_once dirname( __FILE__ ) . '/theme-widgets.php';	// fungsi buat widgets ada di sini
require_once dirname( __FILE__ ) . '/assets/shortcodes/zilla-shortcodes.php'; // di sini fungsi buat shortcode
require_once dirname( __FILE__ ) . '/assets/avatar.php'; // di sini fungsi buat avatar profile
require_once dirname( __FILE__ ) . '/assets/metaboxes/metabox.php'; // di sini fungsi buat shortcode
require_once dirname( __FILE__ ) . '/assets/google-map.php'; // fungsi konak porn
require_once dirname( __FILE__ ) . '/assets/magz-twitter-sidebar-widget/magz_twitter_widget.php'; // fungsi nyanyian burung
require_once dirname( __FILE__ ) . '/assets/post-rating/post-rating.php'; // fungsi post rating
require_once dirname( __FILE__ ) . '/assets/typo.php'; // fungsi buat google fonts dan custom css nya

?>