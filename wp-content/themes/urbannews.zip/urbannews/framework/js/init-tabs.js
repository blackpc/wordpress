$ = jQuery.noConflict();

jQuery(function($){
$(document).ready(function(){

$(".idTabs").idTabs(true,location.hash);

}); // END doc ready
}); // END function
