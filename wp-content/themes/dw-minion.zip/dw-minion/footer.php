        </div>
      </div>
    </div>
    <footer id="colophon" class="site-footer" role="contentinfo">
      <div class="container">
        <div class="site-info">
          <a href="http://wp-templates.ru/" title="темы и шаблоны wordpress">шаблоны сайтов</a>, <a href="http://flowertimes.ru/" title="растения и цветы">декоративные цветы</a>
        </div>
      </div>
    </footer>
  </div>
</div>

<?php wp_footer(); ?>

</body>
</html>