=== DW Minion ===
Author: DesignWall
Author URL: http://www.designwall.com
Requires at least: 3.5.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== About ==
FREE Responsive WordPress Theme For Personal Blog

== Theme Installation ==
This section describes how to install the theme into your existing WordPress site:

1. Log in to WordPress Administration Panels.
2. Select the `Appearance` panel, then select `Themes`.
3. Click on `Install Themes`.
4. Click on `Upload` on the top sub-menu and browse the `dw-minion_1.0.0_theme.zip` file, then click on `Install now` button.
5. Click on the `Live Preview` link to preview the Theme or `Active` link to start using the Theme.

== Support ==
Please post your questions in Questions & Answers page or drop us an email to help@designwall.com